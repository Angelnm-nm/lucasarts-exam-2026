package lucasarts.Data;

import lucasarts.Domain.CharacterModel;

import java.util.ArrayList;
import java.util.Objects;

public class CharacterMemLocalDataSource {

    private static CharacterMemLocalDataSource instance = null;

    private ArrayList<CharacterModel> storage = new ArrayList<>();

    public ArrayList<CharacterModel> findAll() {
        return storage;
    }

    public void add(CharacterModel character) {
        storage.add(character);
    }

    public void delete(String characterId) {
        storage.removeIf(character -> Objects.equals(character.getId(), characterId));
    }

    private static CharacterMemLocalDataSource newInstance() {
        if (instance == null) {
            instance = new CharacterMemLocalDataSource();
        }
        return instance;
    }
}
